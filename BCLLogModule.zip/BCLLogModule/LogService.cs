﻿using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using System;

namespace BCLLogModule
{
    public class LogService
    {
        private readonly ILogger<LogService> _logger;

        public LogService(ILogger<LogService> logger = null)
        {
            _logger = logger ?? NullLogger<LogService>.Instance;
        }

        public void DoSomething(string Param)
        {
            _logger.LogInformation(Param);

        }

    }
}
