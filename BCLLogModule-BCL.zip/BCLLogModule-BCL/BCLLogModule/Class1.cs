﻿using System;

namespace BCLLogModule
{
    public class Class1
    {
        
    }
}
