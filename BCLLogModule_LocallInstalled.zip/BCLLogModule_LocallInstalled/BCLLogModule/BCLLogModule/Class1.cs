﻿using System;

namespace BCLLogModule
{
    public class LogService
    {
        private readonly ILogger<LogService> _logger;

        public MyService(ILogger<LogService> logger = null)
        {
            _logger = logger ?? NullLogger<MyService>.Instance;
        }

        public void LogMessage(string Param)
        {
            _logger?.LogInformation(Param);
            
        }

    }
}
